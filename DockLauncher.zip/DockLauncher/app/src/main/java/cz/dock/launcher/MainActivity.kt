package cz.dock.launcher

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.database.ContentObserver
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class AppItem(val cn: ComponentName, val label: String, val icon: Drawable)

private class WItem(val info: AppWidgetProviderInfo, val label: String, val app: String, val icon: Drawable?)

class MainActivity : Activity() {

    private val REQ_BIND = 1
    private val REQ_CONFIG = 2

    private lateinit var awm: AppWidgetManager
    private lateinit var host: AppWidgetHost
    private lateinit var grid: WidgetGrid
    private lateinit var dock: LinearLayout
    private lateinit var drawer: FrameLayout
    private lateinit var searchBox: EditText
    private lateinit var appGrid: GridView
    private lateinit var prefs: SharedPreferences
    private lateinit var volBar: VolumeBar

    private var apps = listOf<AppItem>()
    private var shownApps = listOf<AppItem>()
    private val appAdapter = AppAdapter()
    private var pendingId = -1

    private val volObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { volBar.invalidate() }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = loadApps()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)

        grid = WidgetGrid(this)
        grid.onLongPress = { id -> if (id == -1) pickWidget() else widgetMenu(id) }
        grid.onChanged = { saveWidgets() }

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(0x99000000.toInt())
                cornerRadius = dp(32).toFloat()
            }
        }
        val dockWrap = FrameLayout(this).apply {
            clipChildren = false
            setPadding(0, dp(14), 0, dp(14))
            addView(dock, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(dockWrap, LinearLayout.LayoutParams(-1, -2))
        }
        volBar = VolumeBar(this)
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            addView(col, LinearLayout.LayoutParams(0, -1, 1f))
            addView(volBar, LinearLayout.LayoutParams(dp(44), -1).apply { setMargins(dp(8), dp(16), dp(16), dp(16)) })
        }
        drawer = buildDrawer()
        setContentView(FrameLayout(this).apply {
            fitsSystemWindows = true
            clipChildren = false
            addView(main, -1, -1)
            addView(drawer, -1, -1)
        })

        // obnov uložené widgety
        prefs.getString("w", "")!!.split(";").filter { it.isNotBlank() }.forEach { s ->
            val p = s.split(",").map { it.toInt() }
            val info = awm.getAppWidgetInfo(p[0])
            if (info != null) grid.add(p[0], p[1], p[2], p[3], p[4], makeView(p[0], info))
        }

        loadApps()
        contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, volObserver)
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
    }

    override fun onStart() { super.onStart(); host.startListening() }
    override fun onStop() { super.onStop(); host.stopListening() }
    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(pkgReceiver)
        contentResolver.unregisterContentObserver(volObserver)
    }

    override fun onBackPressed() { if (grid.editing) grid.stopEdit() else hideDrawer() }

    // ---------- gesta: zespodu nahoru = otevřít, shora dolů = zavřít ----------

    private var gx = 0f
    private var gy = 0f
    private var gMode = 0 // 0 nic, 1 čekáme na swipe nahoru, 2 čekáme na swipe dolů

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gx = e.rawX; gy = e.rawY
                val h = window.decorView.height
                gMode = when {
                    drawer.visibility == View.VISIBLE -> if (!appGrid.canScrollVertically(-1)) 2 else 0
                    !grid.editing && e.rawY > h - dp(180) -> 1
                    else -> 0
                }
            }
            MotionEvent.ACTION_MOVE -> if (gMode != 0) {
                val dy = e.rawY - gy
                val dx = Math.abs(e.rawX - gx)
                if (gMode == 1 && -dy > dp(70) && -dy > dx * 1.5f) {
                    gMode = 0
                    drawer.visibility = View.VISIBLE
                } else if (gMode == 2 && dy > dp(90) && dy > dx * 1.5f) {
                    gMode = 0
                    hideDrawer()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> gMode = 0
        }
        return super.dispatchTouchEvent(e)
    }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); grid.stopEdit(); hideDrawer() }

    // ---------- aplikace ----------

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0).map {
                AppItem(
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                    it.loadLabel(pm).toString(),
                    it.loadIcon(pm)
                )
            }.sortedBy { it.label.lowercase() }
            runOnUiThread { apps = list; filterApps(searchBox.text.toString()); buildDock() }
        }.start()
    }

    private fun filterApps(q: String) {
        val k = q.trim().lowercase()
        shownApps = if (k.isEmpty()) apps else apps.filter { it.label.lowercase().contains(k) }
        appAdapter.notifyDataSetChanged()
    }

    private fun launch(a: AppItem) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Nejde spustit", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- dock ----------

    private fun dockList(): List<String> = prefs.getString("d", "")!!.split(",").filter { it.isNotBlank() }
    private fun saveDock(l: List<String>) = prefs.edit().putString("d", l.joinToString(",")).apply()

    private fun buildDock() {
        dock.removeAllViews()
        val map = apps.associateBy { it.cn.flattenToString() }
        for (k in dockList()) map[k]?.let { dock.addView(dockIcon(it)) }
        if (dock.childCount == 0) {
            dock.addView(TextView(this).apply {
                text = "Přejeď prstem zespodu nahoru pro aplikace"
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding(dp(12), dp(8), dp(12), dp(8))
            })
        }
    }

    private fun dockIcon(a: AppItem) = ImageView(this).apply {
        setImageDrawable(a.icon)
        layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(dp(10), 0, dp(10), 0) }
        tvFx(this)
        setOnClickListener { launch(a) }
        setOnLongClickListener {
            confirm("Odebrat z docku?") { saveDock(dockList() - a.cn.flattenToString()); buildDock() }
            true
        }
    }

    /** tvOS efekt: ikona se při dotyku/fokusu zvětší a trochu povyskočí. */
    private fun tvFx(v: View) {
        v.isFocusable = true
        fun s(on: Boolean) {
            v.animate().scaleX(if (on) 1.25f else 1f).scaleY(if (on) 1.25f else 1f)
                .translationY(if (on) -dp(8).toFloat() else 0f).setDuration(120).start()
        }
        v.setOnFocusChangeListener { _, f -> s(f) }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> s(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> s(false)
            }
            false
        }
    }

    // ---------- drawer ----------

    private fun buildDrawer(): FrameLayout {
        searchBox = EditText(this).apply {
            hint = "Hledat aplikaci"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply {
                setColor(0x33FFFFFF)
                cornerRadius = dp(20).toFloat()
            }
            addTextChangedListener(Watcher { filterApps(it) })
            setOnEditorActionListener { _, _, _ ->
                shownApps.firstOrNull()?.let { launch(it); hideDrawer() }
                true
            }
        }
        val gv = GridView(this).apply {
            numColumns = GridView.AUTO_FIT
            columnWidth = dp(110)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(12)
            setPadding(dp(24), dp(16), dp(24), dp(24))
            setSelector(ColorDrawable(0))
            adapter = appAdapter
            setOnItemClickListener { _, _, i, _ -> launch(shownApps[i]); hideDrawer() }
            setOnItemLongClickListener { _, _, i, _ ->
                val k = shownApps[i].cn.flattenToString()
                if (k !in dockList()) {
                    saveDock(dockList() + k); buildDock()
                    Toast.makeText(this@MainActivity, "Přidáno do docku", Toast.LENGTH_SHORT).show()
                }
                true
            }
        }
        appGrid = gv
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(searchBox, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(24), dp(20), dp(24), 0) })
            addView(gv, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        return FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(0xE6101015.toInt())
            addView(content, -1, -1)
        }
    }

    private fun hideDrawer() {
        searchBox.setText("")
        searchBox.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchBox.windowToken, 0)
        drawer.visibility = View.GONE
    }

    inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shownApps.size
        override fun getItem(i: Int) = shownApps[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val row = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(ImageView(context), LinearLayout.LayoutParams(dp(56), dp(56)))
                addView(TextView(context).apply {
                    setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(-1, -2))
            }
            val a = shownApps[i]
            (row.getChildAt(0) as ImageView).setImageDrawable(a.icon)
            (row.getChildAt(1) as TextView).text = a.label
            return row
        }
    }

    // ---------- widgety ----------

    private fun makeView(id: Int, info: AppWidgetProviderInfo) = host.createView(this, id, info)

    private fun widgetMenu(id: Int) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Upravit pozici a velikost", "Odebrat widget")) { _, i ->
                if (i == 0) {
                    grid.startEdit(id)
                    Toast.makeText(
                        this,
                        "Táhni widget. Velikost měň kolečkem vpravo dole. Klepnutím mimo skončíš.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    grid.remove(id); host.deleteAppWidgetId(id); saveWidgets()
                }
            }.show()
    }

    private fun saveWidgets() = prefs.edit().putString("w", grid.serialize()).apply()

    private fun pickWidget() {
        val pm = packageManager
        val dpi = resources.displayMetrics.densityDpi
        val iconCache = HashMap<String, Drawable?>()
        val items = awm.installedProviders.map { p ->
            val pkg = p.provider.packageName
            val app = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
            val icon = iconCache.getOrPut(pkg) {
                try { pm.getApplicationIcon(pkg) } catch (e: Exception) { p.loadIcon(this, dpi) }
            }
            WItem(p, p.loadLabel(pm), app, icon)
        }.sortedWith(compareBy({ it.app.lowercase() }, { it.label.lowercase() }))

        val shown = ArrayList<WItem>(items)
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(i: Int) = shown[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val row = (v as? LinearLayout) ?: LinearLayout(p!!.context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    addView(ImageView(context), LinearLayout.LayoutParams(dp(40), dp(40)))
                    addView(LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(16), 0, 0, 0)
                        addView(TextView(context).apply {
                            textSize = 16f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                        })
                        addView(TextView(context).apply {
                            textSize = 12f; alpha = 0.6f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                        })
                    })
                }
                val w = shown[i]
                (row.getChildAt(0) as ImageView).setImageDrawable(w.icon)
                val texts = row.getChildAt(1) as LinearLayout
                (texts.getChildAt(0) as TextView).text = w.label
                (texts.getChildAt(1) as TextView).text = w.app
                return row
            }
        }

        val b = AlertDialog.Builder(this)
        val ctx = b.context
        val search = EditText(ctx).apply {
            hint = "Hledat widget nebo aplikaci"
            isSingleLine = true
        }
        val list = ListView(ctx)
        list.adapter = adapter
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), 0)
            addView(search, LinearLayout.LayoutParams(-1, -2))
            addView(list, LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.55).toInt()))
        }
        val dialog = b.setTitle("Přidat widget").setView(box).create()
        list.setOnItemClickListener { _, _, i, _ -> dialog.dismiss(); startBind(shown[i].info) }
        search.addTextChangedListener(Watcher { q ->
            val k = q.trim().lowercase()
            shown.clear()
            shown.addAll(
                if (k.isEmpty()) items
                else items.filter { it.label.lowercase().contains(k) || it.app.lowercase().contains(k) }
            )
            adapter.notifyDataSetChanged()
        })
        dialog.show()
    }

    private fun startBind(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) afterBind(id)
        else startActivityForResult(
            Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider), REQ_BIND
        )
    }

    private fun afterBind(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
        else addWidget(id)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != REQ_BIND && req != REQ_CONFIG) return
        if (res != RESULT_OK) { host.deleteAppWidgetId(pendingId); return }
        if (req == REQ_BIND) afterBind(pendingId) else addWidget(pendingId)
    }

    private fun addWidget(id: Int) {
        val info = awm.getAppWidgetInfo(id) ?: return
        val cs = grid.cellSize()
        val sx = ((info.minWidth + cs - 1) / cs).coerceIn(1, grid.cols)
        val sy = ((info.minHeight + cs - 1) / cs).coerceIn(1, grid.rowCount())
        val pos = grid.findSpot(sx, sy)
        if (pos == null) {
            Toast.makeText(this, "Není místo", Toast.LENGTH_SHORT).show()
            host.deleteAppWidgetId(id)
            return
        }
        grid.add(id, pos.first, pos.second, sx, sy, makeView(id, info))
        saveWidgets()
    }

    private fun confirm(t: String, ok: () -> Unit) =
        AlertDialog.Builder(this).setTitle(t)
            .setPositiveButton("Ano") { _, _ -> ok() }
            .setNegativeButton("Ne", null).show()
}
