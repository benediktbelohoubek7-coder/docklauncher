package cz.dock.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.AudioManager
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup

/** Mřížka widgetů: pevný počet sloupců, widgety se skládají do prvního volného místa. */
class WidgetGrid(ctx: Context, val cols: Int = 8) : ViewGroup(ctx) {

    private class W(val id: Int, val c: Int, val r: Int, val sx: Int, val sy: Int, val v: View)

    private val items = ArrayList<W>()
    private val pad = (6 * resources.displayMetrics.density).toInt()

    fun cellSize(): Int =
        (if (width > 0) width else resources.displayMetrics.widthPixels) / cols

    fun rowCount(): Int =
        maxOf(1, (if (height > 0) height else resources.displayMetrics.heightPixels * 2 / 3) / cellSize())

    fun add(id: Int, c: Int, r: Int, sx: Int, sy: Int, v: View) {
        items.add(W(id, c, r, sx, sy, v))
        addView(v)
    }

    fun remove(id: Int) {
        val w = items.find { it.id == id } ?: return
        removeView(w.v)
        items.remove(w)
    }

    fun findSpot(sx: Int, sy: Int): Pair<Int, Int>? {
        for (r in 0..(rowCount() - sy)) for (c in 0..(cols - sx)) {
            val free = items.none { c < it.c + it.sx && it.c < c + sx && r < it.r + it.sy && it.r < r + sy }
            if (free) return Pair(c, r)
        }
        return null
    }

    fun serialize(): String = items.joinToString(";") { "${it.id},${it.c},${it.r},${it.sx},${it.sy}" }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(getDefaultSize(0, wSpec), getDefaultSize(0, hSpec))
        val cs = measuredWidth / cols
        for (w in items) {
            w.v.measure(
                MeasureSpec.makeMeasureSpec((cs * w.sx - 2 * pad).coerceAtLeast(1), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec((cs * w.sy - 2 * pad).coerceAtLeast(1), MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cs = (r - l) / cols
        for (w in items) {
            val x = w.c * cs + pad
            val y = w.r * cs + pad
            w.v.layout(x, y, x + w.v.measuredWidth, y + w.v.measuredHeight)
        }
    }
}

/** Tlačítko "všechny aplikace" – 3x3 tečky, kreslené kódem (žádné obrázky). */
class DotsView(c: Context) : View(c) {
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        cv.drawRoundRect(0f, 0f, w, height.toFloat(), w * .22f, w * .22f, bg)
        for (i in 0..2) for (j in 0..2) cv.drawCircle(w * (.3f + .2f * i), w * (.3f + .2f * j), w * .045f, dot)
    }
}

/** Svislý ovladač hlasitosti: tažením nahoru/dolů nastavíš hlasitost médií. */
class VolumeBar(c: Context) : View(c) {
    private val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99000000.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FFFFFF.toInt() }
    private val shape = Path()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        shape.reset()
        shape.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), w / 2f, w / 2f, Path.Direction.CW)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        cv.drawPath(shape, bg)
        val v = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        cv.save()
        cv.clipPath(shape)
        cv.drawRect(0f, h - h * v, w, h, fill)
        cv.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent.requestDisallowInterceptTouchEvent(true)
                val f = 1f - (e.y / height).coerceIn(0f, 1f)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(f * max), 0)
                invalidate()
            }
        }
        return true
    }
}
