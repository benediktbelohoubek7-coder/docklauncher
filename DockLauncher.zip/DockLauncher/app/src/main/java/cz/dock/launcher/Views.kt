package cz.dock.launcher

import android.appwidget.AppWidgetHostView
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.AudioManager
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup

/** Mřížka widgetů: pevný počet sloupců, widgety jde přesouvat a měnit jim velikost. */
class WidgetGrid(ctx: Context, val cols: Int = 8) : ViewGroup(ctx) {

    private class W(val id: Int, var c: Int, var r: Int, var sx: Int, var sy: Int, val v: View) {
        var lw = 0
        var lh = 0
    }

    private val items = ArrayList<W>()
    private val density = resources.displayMetrics.density
    private val pad = (6 * density).toInt()
    private val handleR = 14 * density
    private val touchR = 36 * density
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3 * density
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()

    var editId = -1
        private set
    val editing: Boolean get() = editId != -1
    var onChanged: (() -> Unit)? = null
    /** Dlouhý stisk: id widgetu pod prstem, nebo -1 na prázdném místě. */
    var onLongPress: ((Int) -> Unit)? = null

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private var swallow = false
    private var lx = 0f
    private var ly = 0f
    private var dt = 0L
    private val lp = Runnable {
        // zruš dotyk u widgetu, ať si nemyslí, že je stále stisknutý
        val now = SystemClock.uptimeMillis()
        val c = MotionEvent.obtain(dt, now, MotionEvent.ACTION_CANCEL, lx, ly, 0)
        dispatchSuper(c)
        c.recycle()
        swallow = true
        onLongPress?.invoke(hit(lx, ly))
    }

    private var mode = 0 // 0 nic, 1 přesun, 2 změna velikosti
    private var x0 = 0f
    private var y0 = 0f
    private var oc = 0
    private var orow = 0
    private var osx = 0
    private var osy = 0

    fun cellSize(): Int =
        (if (width > 0) width else resources.displayMetrics.widthPixels) / cols

    fun rowCount(): Int =
        maxOf(1, (if (height > 0) height else resources.displayMetrics.heightPixels * 2 / 3) / cellSize())

    fun add(id: Int, c: Int, r: Int, sx: Int, sy: Int, v: View) {
        items.add(W(id, c, r, sx, sy, v))
        addView(v)
    }

    fun remove(id: Int) {
        val w = items.find { it.id == id } ?: return
        removeView(w.v)
        items.remove(w)
        if (editId == id) stopEdit()
    }

    fun startEdit(id: Int) { editId = id; mode = 0; invalidate() }
    fun stopEdit() { editId = -1; mode = 0; invalidate() }

    private fun fits(w: W?, c: Int, r: Int, sx: Int, sy: Int): Boolean {
        if (c < 0 || r < 0 || sx < 1 || sy < 1 || c + sx > cols || r + sy > rowCount()) return false
        return items.none { it !== w && c < it.c + it.sx && it.c < c + sx && r < it.r + it.sy && it.r < r + sy }
    }

    fun findSpot(sx: Int, sy: Int): Pair<Int, Int>? {
        for (r in 0..(rowCount() - sy)) for (c in 0..(cols - sx)) {
            if (fits(null, c, r, sx, sy)) return Pair(c, r)
        }
        return null
    }

    fun serialize(): String = items.joinToString(";") { "${it.id},${it.c},${it.r},${it.sx},${it.sy}" }

    // ---------- měření a rozložení ----------

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(getDefaultSize(0, wSpec), getDefaultSize(0, hSpec))
        val cs = measuredWidth / cols
        for (w in items) {
            w.v.measure(
                MeasureSpec.makeMeasureSpec((cs * w.sx - 2 * pad).coerceAtLeast(1), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec((cs * w.sy - 2 * pad).coerceAtLeast(1), MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cs = (r - l) / cols
        for (w in items) {
            val x = w.c * cs + pad
            val y = w.r * cs + pad
            val pw = w.v.measuredWidth
            val ph = w.v.measuredHeight
            w.v.layout(x, y, x + pw, y + ph)
            if (pw != w.lw || ph != w.lh) {
                w.lw = pw; w.lh = ph
                val dw = (pw / density).toInt()
                val dh = (ph / density).toInt()
                (w.v as? AppWidgetHostView)?.updateAppWidgetSize(null, dw, dh, dw, dh)
            }
        }
    }

    // ---------- úpravy: přesun + změna velikosti ----------

    override fun dispatchDraw(cv: Canvas) {
        super.dispatchDraw(cv)
        val w = items.find { it.id == editId } ?: return
        val cs = cellSize()
        rect.set(
            (w.c * cs + pad).toFloat(), (w.r * cs + pad).toFloat(),
            ((w.c + w.sx) * cs - pad).toFloat(), ((w.r + w.sy) * cs - pad).toFloat()
        )
        cv.drawRoundRect(rect, 12 * density, 12 * density, border)
        cv.drawCircle(rect.right, rect.bottom, handleR, handle)
    }

    private fun dispatchSuper(e: MotionEvent): Boolean = super.dispatchTouchEvent(e)

    private fun hit(x: Float, y: Float): Int {
        val cs = cellSize()
        for (w in items) {
            val l = (w.c * cs + pad).toFloat()
            val t = (w.r * cs + pad).toFloat()
            val r = ((w.c + w.sx) * cs - pad).toFloat()
            val b = ((w.r + w.sy) * cs - pad).toFloat()
            if (x in l..r && y in t..b) return w.id
        }
        return -1
    }

    /** Dlouhý stisk hlídáme tady, protože widgety si dotyky často berou samy. */
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (swallow) {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) swallow = false
            return true
        }
        if (!editing) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lx = e.x; ly = e.y; dt = e.downTime
                    removeCallbacks(lp)
                    postDelayed(lp, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE ->
                    if (Math.abs(e.x - lx) > slop || Math.abs(e.y - ly) > slop) removeCallbacks(lp)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(lp)
            }
        }
        return super.dispatchTouchEvent(e)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = editing

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return true   // přijmi dotyk, ať přijde i dlouhý stisk na prázdném místě
        val w = items.find { it.id == editId } ?: return true
        val cs = cellSize()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val l = (w.c * cs + pad).toFloat()
                val t = (w.r * cs + pad).toFloat()
                val rt = ((w.c + w.sx) * cs - pad).toFloat()
                val bt = ((w.r + w.sy) * cs - pad).toFloat()
                mode = when {
                    Math.abs(e.x - rt) < touchR && Math.abs(e.y - bt) < touchR -> 2
                    e.x in l..rt && e.y in t..bt -> 1
                    else -> 0
                }
                if (mode == 0) { stopEdit(); return true }
                x0 = e.x; y0 = e.y
                oc = w.c; orow = w.r; osx = w.sx; osy = w.sy
            }
            MotionEvent.ACTION_MOVE -> {
                val dc = Math.round((e.x - x0) / cs)
                val dr = Math.round((e.y - y0) / cs)
                if (mode == 1) {
                    val nc = (oc + dc).coerceIn(0, cols - w.sx)
                    val nr = (orow + dr).coerceIn(0, maxOf(0, rowCount() - w.sy))
                    when {
                        fits(w, nc, nr, w.sx, w.sy) -> move(w, nc, nr)
                        fits(w, nc, w.r, w.sx, w.sy) -> move(w, nc, w.r)
                        fits(w, w.c, nr, w.sx, w.sy) -> move(w, w.c, nr)
                    }
                } else if (mode == 2) {
                    val nsx = (osx + dc).coerceIn(1, maxOf(1, cols - w.c))
                    val nsy = (osy + dr).coerceIn(1, maxOf(1, rowCount() - w.r))
                    if (fits(w, w.c, w.r, nsx, nsy)) { w.sx = nsx; w.sy = nsy; requestLayout(); invalidate() }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode != 0) onChanged?.invoke()
                mode = 0
            }
        }
        return true
    }

    private fun move(w: W, c: Int, r: Int) {
        if (w.c == c && w.r == r) return
        w.c = c; w.r = r
        requestLayout(); invalidate()
    }
}

/** Tlačítko "všechny aplikace" – 3x3 tečky, kreslené kódem (žádné obrázky). */
class DotsView(c: Context) : View(c) {
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        cv.drawRoundRect(0f, 0f, w, height.toFloat(), w * .22f, w * .22f, bg)
        for (i in 0..2) for (j in 0..2) cv.drawCircle(w * (.3f + .2f * i), w * (.3f + .2f * j), w * .045f, dot)
    }
}

/** Svislý ovladač hlasitosti: tažením nahoru/dolů nastavíš hlasitost médií. */
class VolumeBar(c: Context) : View(c) {
    private val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99000000.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FFFFFF.toInt() }
    private val shape = Path()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        shape.reset()
        shape.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), w / 2f, w / 2f, Path.Direction.CW)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        cv.drawPath(shape, bg)
        val v = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        cv.save()
        cv.clipPath(shape)
        cv.drawRect(0f, h - h * v, w, h, fill)
        cv.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent.requestDisallowInterceptTouchEvent(true)
                val f = 1f - (e.y / height).coerceIn(0f, 1f)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(f * max), 0)
                invalidate()
            }
        }
        return true
    }
}

/** Jednoduchý TextWatcher, který jen předá nový text. */
class Watcher(private val f: (String) -> Unit) : TextWatcher {
    override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
}
